from functools import lru_cache
from typing import Dict, Any, Optional
import time
import logging
from error_handler import ErrorHandler

logger = logging.getLogger(__name__)


class CacheManager:
    _instance = None
    _word_info_cache: Dict[str, Dict[str, Any]] = {}
    _cache_timeout = 3600  # 1 hour

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(CacheManager, cls).__new__(cls)
        return cls._instance

    @staticmethod
    def get_word_info(word: str) -> Optional[Any]:
        """Get word info from cache if available and not expired"""
        try:
            current_time = time.time()
            if word in CacheManager._word_info_cache:
                cached_data = CacheManager._word_info_cache[word]
                if current_time - cached_data['timestamp'] < CacheManager._cache_timeout:
                    logger.info(f"Cache hit for word: {word}")
                    return cached_data['data']
                else:
                    logger.info(f"Cache expired for word: {word}")
                    del CacheManager._word_info_cache[word]
            logger.info(f"No cache entry for word: {word}")
            return None
        except Exception as e:
            ErrorHandler.log_error(e, "Cache retrieval")
            return None

    @staticmethod
    def cache_word_info(word: str, data: Any) -> None:
        """Cache word info with timestamp"""
        try:
            if word not in CacheManager._word_info_cache:  # Only cache if not already present
                CacheManager._word_info_cache[word] = {
                    'data': data,
                    'timestamp': time.time()
                }
                logger.info(f"Cached word info for: {word}")
            else:
                logger.info(f"Word already in cache: {word}")
        except Exception as e:
            ErrorHandler.log_error(e, "Cache storage")

    @staticmethod
    def clear_cache() -> None:
        """Clear all cached data"""
        try:
            CacheManager._word_info_cache.clear()
            CacheManager.get_word_info.cache_clear()  # Clear lru_cache
            logger.info("Cache cleared")
        except Exception as e:
            ErrorHandler.log_error(e, "Cache clearing")

    @staticmethod
    def get_cache_stats() -> Dict[str, Any]:
        """Get cache statistics"""
        try:
            return {
                'size': len(CacheManager._word_info_cache),
                'hits': CacheManager.get_word_info.cache_info().hits,
                'misses': CacheManager.get_word_info.cache_info().misses,
                'max_size': CacheManager.get_word_info.cache_info().maxsize
            }
        except Exception as e:
            ErrorHandler.log_error(e, "Cache stats retrieval")
            return {}

    @staticmethod
    def remove_expired_entries() -> None:
        """Remove all expired cache entries"""
        try:
            current_time = time.time()
            expired_keys = [
                word for word, data in CacheManager._word_info_cache.items()
                if current_time - data['timestamp'] >= CacheManager._cache_timeout
            ]
            for word in expired_keys:
                del CacheManager._word_info_cache[word]
            logger.info(f"Removed {len(expired_keys)} expired cache entries")
        except Exception as e:
            ErrorHandler.log_error(e, "Cache cleanup")
