import flet as ft
from typing import Dict, Any, Optional
from panel_factory import PanelFactory
from error_handler import ErrorHandler
from utils import safe_ui_operation, debug_system  # Update these imports





class CanvasBuilder:
    def __init__(self):
        debug_system.log_flow("Initializing CanvasBuilder")
        self.canvas = ft.Container(
            expand=True,
            bgcolor=ft.colors.GREY_900,
            border_radius=4,
            padding=10
        )
        self.panels: Dict[str, Any] = {}
        self.layout = None
        self.panel_configs = {
            'left': {
                'width': 300,
                'col': {"xs": 12, "sm": 6, "md": 6, "lg": 3},
                'bgcolor': ft.colors.GREY_900,
            },
            'right': {
                'width': 300,
                'col': {"xs": 12, "sm": 6, "md": 6, "lg": 3},
                'bgcolor': ft.colors.GREY_900,
            },
            'middle': {
                'width': 300,
                'col': {"xs": 12, "sm": 12, "md": 12, "lg": 6},
                'bgcolor': ft.colors.GREY_900,
            }
        }

    def add_panel(self, panel_type: str, config: Optional[Dict[str, Any]] = None, **kwargs) -> 'CanvasBuilder':
        """Add a panel to the canvas"""
        debug_system.log_flow(f"Adding panel: {panel_type}")
        try:
            if config is None:
                config = self.panel_configs.get(panel_type, {})
            
            panel = PanelFactory.create_panel(panel_type, config, **kwargs)
            if panel:
                self.panels[panel_type] = panel
                debug_system.log_flow(f"Successfully added panel: {panel_type}")
            else:
                raise ValueError(f"Failed to create panel: {panel_type}")
                
            return self
        except Exception as e:
            debug_system.log_error(e, f"Error adding panel {panel_type}")
            raise

    def set_layout(self, layout_type: str = "responsive") -> 'CanvasBuilder':
        """Set the layout type for the canvas"""
        debug_system.log_flow(f"Setting layout: {layout_type}")
        try:
            if layout_type == "responsive":
                # Verify all required panels exist
                required_panels = ['left', 'middle', 'right']
                missing_panels = [p for p in required_panels if p not in self.panels]
                if missing_panels:
                    raise ValueError(f"Missing required panels: {missing_panels}")
                
                # Create layout with existing panels
                self.layout = ft.ResponsiveRow(
                    controls=[self.panels[p] for p in required_panels],
                    expand=True,
                    vertical_alignment=ft.CrossAxisAlignment.START
                )
                debug_system.log_flow("Layout set successfully")
            else:
                raise ValueError(f"Unsupported layout type: {layout_type}")
            
            return self
        except Exception as e:
            debug_system.log_error(e, "Error setting layout")
            raise

    def add_controls(self, controls: list) -> 'CanvasBuilder':
        """Add additional controls to the canvas"""
        try:
            if not self.layout:
                self.layout = ft.Column(controls=controls, expand=True)
            else:
                self.layout.controls.extend(controls)
            return self
        except Exception as e:
            ErrorHandler.handle_operation(
                "Adding controls",
                lambda: None,
                error_dialog=True
            )
            return self

    def build(self) -> ft.Container:
        """Build and return the final canvas"""
        debug_system.log_flow("Building canvas")
        try:
            if not self.layout:
                raise ValueError("Layout must be set before building")
            
            self.canvas.content = self.layout
            debug_system.log_flow("Canvas built successfully")
            return self.canvas
            
        except Exception as e:
            debug_system.log_error(e, "Error building canvas")
            # Return a minimal working container as fallback
            return ft.Container(
                content=ft.Column([
                    ft.Text("Error building canvas", color=ft.colors.RED_400),
                    ft.Text(str(e), color=ft.colors.RED_400, size=12)
                ]),
                bgcolor=ft.colors.GREY_900,
                padding=20
            )

    @staticmethod
    def create_default_canvas() -> ft.Container:
        """Create a default canvas with standard layout"""
        debug_system.log_flow("Creating default canvas")
        builder = CanvasBuilder()
        try:
            return (builder
                    .add_panel('right')
                    .add_panel('left')
                    .add_panel('middle', right_panel=builder.panels.get('right'))
                    .set_layout()
                    .build())
        except Exception as e:
            debug_system.log_error(e, "Error creating default canvas")
            raise
