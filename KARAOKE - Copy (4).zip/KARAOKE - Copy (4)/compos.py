import flet as ft
from constants import GradientPatterns, ShadowPatterns




# DoubleContainer
class DoubleContainer(ft.Container):
    def __init__(self, imagen, ptexto, stexto):
        super().__init__()
        #self.width = 400
        self.height = 100
        self.border_radius = 8
        self.bgcolor = "white"
        self.padding = 8
        self.shadow= ShadowPatterns.MEDIUM_01
        self.gradient= GradientPatterns.GREY_TLBR # crear gradient
        self.scale = ft.transform.Scale(scale=1)
        self.animate_scale = ft.animation.Animation(400, ft.AnimationCurve.BOUNCE_OUT)
        self.on_hover = None #self._sobre_main
        self.on_click = None
        
        #--- non parent related
        self.imagen = imagen
        self.ptexto = ptexto
        self.stexto = stexto
        self.content = self._create_content()

    # Create content
    def _create_content(self):
        return ft.Row([
            self._create_image(),
            self._create_text_column()
        ])
    
    # UI Interaction
    def _sobre_main(self,e):
        container = e.control
        if e.data == "true":
            container.scale=ft.transform.Scale(scale=1.1)
        else:
            container.scale=ft.transform.Scale(scale=1)
        container.update()    
    
    # Components creation
    def _create_image(self):
        return ft.Container(
            width=80,
            #height=80,
            border=ft.border.all(1, ft.colors.GREY_800),
            border_radius=8,
            shadow= ShadowPatterns.MEDIUM_01,
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            #blur=BlurPatterns.MEDIUM_BLUR,
            content=ft.Image(
                border_radius=8,
                src=self.imagen,
                fit=ft.ImageFit.COVER
            )
        )

    # Container con titulo y subtitulo
    def _create_text_column(self):
        return ft.Container(
            padding=ft.padding.only(left=20),
            expand=True,
            bgcolor=ft.colors.BLACK26,
            border_radius=8,
            opacity=0.8,
            #gradient=GradientPatterns.GREY_TLBR,
            #padding=6,
            #blur= BlurPatterns.MEDIUM_BLUR,
            shadow= ShadowPatterns.MEDIUM_02,
            content=ft.Column(
                alignment="center",
                horizontal_alignment="start",
                spacing=1,
                controls=[
                    ft.Text(self.stexto, size=20, color= ft.colors.GREY_300, weight=ft.FontWeight.BOLD),
                    ft.Text(self.ptexto, size=15, color= ft.colors.GREY_700)
                    
                ]
            )
        )
    