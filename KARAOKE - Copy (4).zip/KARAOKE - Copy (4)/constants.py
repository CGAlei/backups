import flet as ft





# CustomTextColumn_01
class CustomTextColumn_01:
    def __init__(self, stexto, ptexto, border_radius=8):
        self.stexto = stexto
        self.ptexto = ptexto
        self.border_radius = border_radius

    def create(self):
        return ft.Container(
            padding=ft.padding.only(left=20),
            expand=True,
            bgcolor=ft.colors.BLACK26,
            border_radius=self.border_radius,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=4,
                color=ft.colors.BLACK54,
                offset=ft.Offset(0, 2),
            ),
            content=ft.Column(
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.START,
                spacing=1,
                controls=[
                    ft.Text(self.stexto, size=20, color=ft.colors.GREY_300, weight=ft.FontWeight.BOLD),
                    ft.Text(self.ptexto, size=15, color=ft.colors.GREY_700)
                ]
            )
        )

# DimensionDisplay
class DimensionDisplay:
    def __init__(self, page: ft.Page):
        self.page = page
        self.pw = ft.Text(theme_style=ft.TextThemeStyle.TITLE_MEDIUM)
        self.ph = ft.Text(theme_style=ft.TextThemeStyle.TITLE_MEDIUM)
        
        self.dimension_row = ft.Row(
            [self.pw, ft.VerticalDivider(width=10), self.ph],
            alignment=ft.MainAxisAlignment.END
        )
        
        self.dimension_container = ft.Container(
            self.dimension_row,
            bottom=50,
            right=50,
            padding=10,
            bgcolor=ft.colors.BLACK54,
            border_radius=8
        )

    def page_resize(self, e):
        self.pw.value = f"Width: {self.page.width}px"
        self.ph.value = f"Height: {self.page.height}px"
        self.page.update()

    def initialize(self):
        self.page.on_resized = self.page_resize
        self.page.overlay.append(self.dimension_container)
        self.page.update()

    @classmethod
    def create(cls, page: ft.Page):
        display = cls(page)
        display.initialize()
        # Set initial values after adding to the page
        display.page_resize(None)
        return display

# AnimationConfig
class AnimationConfig:
    FAST = 200
    NORMAL = 500
    SLOW = 1000

    @staticmethod
    def create_animation(duration=NORMAL, curve=ft.AnimationCurve.EASE_OUT):
        return ft.animation.Animation(duration, curve)
    
    SIDEBAR_SLIDE = create_animation(NORMAL, ft.AnimationCurve.BOUNCE_OUT)
    SIDEBAR_FADE = create_animation(FAST, ft.AnimationCurve.EASE_IN_OUT)
    ITEM_HOVER = create_animation(FAST, ft.AnimationCurve.EASE_IN_OUT)
    CENTRAL_AREA = create_animation(NORMAL, ft.AnimationCurve.EASE_OUT)
    MESSAGE_APPEAR = create_animation(FAST, ft.AnimationCurve.EASE_IN)
    PANEL_RESIZE = create_animation(NORMAL, ft.AnimationCurve.EASE_OUT)
    PANEL_TOGGLE = create_animation(FAST, ft.AnimationCurve.EASE_IN_OUT)

# Blur Patterns
class BlurPatterns:
    MEDIUM_BLUR = ft.Blur(4, 4, ft.BlurTileMode.REPEATED)

# Shadow Patterns
class ShadowPatterns:
    MEDIUM_00 = shadow=ft.BoxShadow(
                        spread_radius=1,
                        blur_radius=8,
                        color=ft.colors.BLACK45,
                        offset=ft.Offset(0, 0),
                        blur_style=ft.ShadowBlurStyle.OUTER
                        )
    
    MEDIUM_01 = shadow=ft.BoxShadow(
                        spread_radius=1,
                        blur_radius=8,
                        color=ft.colors.BLACK45,
                        offset=ft.Offset(1, 1),
                        blur_style=ft.ShadowBlurStyle.OUTER
                        )

    MEDIUM_02 = shadow=ft.BoxShadow(
                        spread_radius=1,
                        blur_radius=1,
                        color=ft.colors.BLACK45,
                        offset=ft.Offset(-1, -1),
                        blur_style=ft.ShadowBlurStyle.OUTER
                        )

# Gradient Patterns
class GradientPatterns:
    GREY_TLBR = ft.LinearGradient(
        begin=ft.alignment.top_left,
        end=ft.alignment.bottom_right,
        colors=[
            "#484848",
            "#444444",
            "#424242",
            "#3b3b3b",
            "#373737",
            "#353535",
            "#343434",
            "#2f2f2f",
            "#2b2b2b"
        ]
    )

    BLUE = ft.LinearGradient(
        begin=ft.alignment.top_center,
        end=ft.alignment.bottom_center,
        colors=[
            "#4a6ea0",
            "#456397",
            "#40598e",
            "#3b5085",
            "#36467c",
            "#313d73",
            "#2c346a",
            "#272b61",
            "#222258"
        ]
    )

    GREEN = ft.LinearGradient(
        begin=ft.alignment.top_center,
        end=ft.alignment.bottom_center,
        colors=[
            "#fd7e14",
            "#f67512",
            "#ef6c10",
            "#e8630e",
            "#e15a0c",
            "#da510a",
            "#d34808",
            "#cc3f06",
            "#c53604",
        ]
    )

# CarData 
class CardData:
    def __init__(self, range_start=301, range_size=40):
        self.range_start = range_start
        self.range_size = range_size
        self.cards = []
        self.generate_cards()

    def generate_image_url(self, index):
        return f"https://picsum.photos/200/{self.range_start + index}"

    def generate_cards(self):
        for i in range(self.range_size):
            self.cards.append({
                "image_url": self.generate_image_url(i),
                "description": f"Description {i+1}",
                "title": f"Card Title {i+1}"
            })

    def get_cards(self):
        return self.cards