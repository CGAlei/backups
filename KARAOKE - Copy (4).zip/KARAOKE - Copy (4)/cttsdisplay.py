import flet as ft
import edge_tts
import pygame
import asyncio
import threading
import time
import logging
from langdetect import detect
import tempfile
import os
from word_info_fetcher_groq import WordInfoFetcher

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class TextToSpeechConfig:
    VOICE_MAP = {
        'en': "en-US-AriaNeural",
        'es': "es-ES-ElviraNeural",
        'fr': "fr-FR-DeniseNeural",
        'de': "de-DE-KatjaNeural",
        'it': "it-IT-ElsaNeural",
        'zh-cn': "zh-CN-XiaoxiaoNeural",
        'ja': "ja-JP-NanamiNeural",
        'ru': "ru-RU-SvetlanaNeural"
    }

class UIComponentFactory:
    @staticmethod
    def create_word_container(text: str, on_hover, on_click) -> ft.Container:
        return ft.Container(
            content=ft.Text(text, size=18),
            padding=1,
            bgcolor=ft.colors.TRANSPARENT,
            border_radius=4,
            ink=True,
            animate_scale=ft.animation.Animation(100, ft.AnimationCurve.EASE_OUT),
            on_hover=on_hover,
            on_click=on_click
        )

    @staticmethod
    def create_audio_controls(on_play, on_stop) -> ft.Row:
        return ft.Row(
            controls=[
                ft.IconButton(
                    icon=ft.icons.PLAY_ARROW,
                    icon_color=ft.colors.WHITE,
                    on_click=on_play
                ),
                ft.IconButton(
                    icon=ft.icons.STOP,
                    icon_color=ft.colors.WHITE,
                    on_click=on_stop
                )
            ]
        )

class AudioManager:
    def __init__(self):
        self.playing = False
        self.audio_file_path = None

    def initialize_audio(self, file_path: str):
        self.audio_file_path = file_path

    def play(self):
        if not self.playing:
            self.playing = True
            pygame.mixer.init()
            pygame.mixer.music.load(self.audio_file_path)
            pygame.mixer.music.play()
            logging.info("Audio playback started")

    def stop(self):
        if self.playing:
            pygame.mixer.music.stop()
            self.playing = False
            logging.info("Audio playback stopped")

class TextProcessor:
    def __init__(self, text: str):
        self.text = text
        self.word_data = []
        
    def detect_language(self) -> str:
        try:
            detected_lang = detect(self.text)
            return TextToSpeechConfig.VOICE_MAP.get(detected_lang, "en-US-AriaNeural")
        except:
            return "en-US-AriaNeural"

    async def process_text(self, audio_file_path: str):
        communicate = edge_tts.Communicate(self.text, self.detect_language())
        
        async def run():
            with open(audio_file_path, "wb") as audio_file:
                async for chunk in communicate.stream():
                    if chunk["type"] == 'audio':
                        audio_file.write(chunk["data"])
                    elif chunk["type"] == 'WordBoundary':
                        self.word_data.append({
                            "texto_palabra": chunk["text"],
                            "marcas_tiempo": {
                                "tiempo_inicio": chunk["offset"] / 10000000
                            }
                        })

        await run()
        return self.word_data

class DisplayBuilder:
    def __init__(self, text_processor: TextProcessor, audio_manager: AudioManager):
        self.text_processor = text_processor
        self.audio_manager = audio_manager
        self.word_containers = []
        self.word_indices = []
        self.content = None
        self.ui_factory = UIComponentFactory()
        self.word_info_fetcher = None  # Will be set later

    def create_hover_handler(self):
        def on_hover(e):
            if not self.audio_manager.playing:
                is_hovering = e.data == "true"
                e.control.bgcolor = ft.colors.BLUE if is_hovering else ft.colors.TRANSPARENT
                e.control.scale = 1.1 if is_hovering else 1.0
                e.control.update()
        return on_hover

    def create_click_handler(self, word_info_fetcher, on_word_click):
        async def on_click(e):
            if not self.audio_manager.playing:
                clicked_word = e.control.content.value
                clean_word = ''.join(char for char in clicked_word if char.isalnum())
                word_info = await self.get_word_details(clean_word, word_info_fetcher)
                on_word_click(word_info)
        return on_click

    async def get_word_details(self, word: str, word_info_fetcher):
        try:
            # Return the WordInfo object directly instead of formatting it as string
            return await asyncio.to_thread(word_info_fetcher.fetch_word_info, word)
        except Exception as e:
            return f"Error fetching details for '{word}': {str(e)}"

    def build_display(self, word_info_fetcher, on_word_click):
        self.word_info_fetcher = word_info_fetcher  # Store the fetcher
        word_rows = self.create_word_rows(word_info_fetcher, on_word_click)
        self.content = ft.Column([word_rows])
        return self.content

    def create_word_rows(self, word_info_fetcher, on_word_click):
        self.word_containers = []
        self.word_indices = []
        current_index = 0
        rows = []
        row_content = []

        def add_row_and_start_new(is_paragraph_break=False):
            nonlocal row_content
            if row_content:
                rows.append(ft.Row(row_content, wrap=True, spacing=0))
                row_content = []
            if is_paragraph_break:
                rows.append(ft.Divider())

        for word_info in self.text_processor.word_data:
            word_text = word_info['texto_palabra']
            start_index = self.text_processor.text.index(word_text, current_index)
            
            if start_index > current_index:
                non_word_text = self.text_processor.text[current_index:start_index]
                
                paragraphs = non_word_text.split('\n\n')
                
                for i, paragraph in enumerate(paragraphs):
                    if i > 0:
                        add_row_and_start_new(is_paragraph_break=True)
                    
                    lines = paragraph.split('\n')
                    for j, line_text in enumerate(lines):
                        if j > 0:
                            add_row_and_start_new()

                        if line_text:
                            row_content.append(ft.Text(line_text, size=16))

            word_container = self.ui_factory.create_word_container(
                word_text,
                on_hover=self.create_hover_handler(),
                on_click=self.create_click_handler(self.word_info_fetcher, on_word_click)
            )
            self.word_containers.append(word_container)
            self.word_indices.append(len(self.word_containers) - 1)
            row_content.append(word_container)
            
            current_index = start_index + len(word_text)

        if current_index < len(self.text_processor.text):
            remaining_text = self.text_processor.text[current_index:]
            paragraphs = remaining_text.split('\n\n')
            
            for i, paragraph in enumerate(paragraphs):
                if i > 0:
                    add_row_and_start_new(is_paragraph_break=True)
                
                lines = paragraph.split('\n')
                for j, line_text in enumerate(lines):
                    if j > 0:
                        add_row_and_start_new()

                    if line_text:
                        row_content.append(ft.Text(line_text, size=18))

        add_row_and_start_new()
        return ft.Column(rows)

class CompoundTextToSpeechDisplay:
    def __init__(self, text: str, on_word_click):
        self.text_processor = TextProcessor(text)
        self.audio_manager = AudioManager()
        self.display_builder = DisplayBuilder(self.text_processor, self.audio_manager)
        self.word_info_fetcher = WordInfoFetcher()
        self.on_word_click = on_word_click
        self.temp_dir = tempfile.gettempdir()
        self.audio_file_path = os.path.join(self.temp_dir, f"audio_{time.time()}.mp3")
        # Initialize async content immediately
        asyncio.run(self.initialize())

    async def initialize(self):
        await self.text_processor.process_text(self.audio_file_path)
        self.audio_manager.initialize_audio(self.audio_file_path)

    def build(self):
        # Now build() can be synchronous since initialization is done in __init__
        content = self.display_builder.build_display(
            self.word_info_fetcher,
            self.on_word_click
        )
        
        audio_controls = UIComponentFactory.create_audio_controls(
            on_play=lambda _: self.start_playback(),
            on_stop=lambda _: self.stop_playback()
        )
        
        return ft.Column([content])
        #return ft.Column([content, audio_controls])

    def start_playback(self):
        if not self.audio_manager.playing:
            self.audio_manager.play()
            threading.Thread(target=self.highlight_words).start()

    def stop_playback(self):
        self.audio_manager.stop()
        # Reset highlighting
        for container in self.display_builder.word_containers:
            container.bgcolor = ft.colors.TRANSPARENT
            container.scale = 1.0
            container.update()

    def highlight_words(self):
        start_time = time.time()
        word_index = 0
        word_containers = self.display_builder.word_containers
        word_data = self.text_processor.word_data

        # Reset all containers to transparent at start
        for container in word_containers:
            container.bgcolor = ft.colors.TRANSPARENT
            container.scale = 1.0
            container.update()

        while word_index < len(word_data) and self.audio_manager.playing:
            current_time = time.time() - start_time
            if current_time >= word_data[word_index]['marcas_tiempo']['tiempo_inicio']:
                # Highlight current word
                container = word_containers[word_index]
                container.bgcolor = ft.colors.ORANGE_900
                container.scale = 1.1

                # Reset previous word to transparent
                if word_index > 0:
                    prev_container = word_containers[word_index - 1]
                    prev_container.bgcolor = ft.colors.TRANSPARENT
                    prev_container.scale = 1.0
                    prev_container.update()

                container.update()
                word_index += 1

                if word_index == len(word_data):
                    time.sleep(1)
                    # Reset the last word to transparent
                    container.bgcolor = ft.colors.TRANSPARENT
                    container.scale = 1.0
                    container.update()
                    self.stop_playback()
                    break

            time.sleep(1/60)

        # Ensure all containers are reset to transparent at the end
        for container in word_containers:
            container.bgcolor = ft.colors.TRANSPARENT
            container.scale = 1.0
            container.update()





# async def main(page: ft.Page):
#     page.title = "Text-to-Speech Highlighter"
#     page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
#     page.scroll = "auto"
    
#     sample_text = "我们讨论了人工智能对翻译行业的影响，特别是对普通翻译者就业机会的冲击。\n你提到在一些高级场合和政府机构，同声传译工作仍然需要人类翻译者。\n\n而普通翻译者的工作可能会被人工智能取代。你也表达了你对找工作困难的担忧，同时希望我能帮你改善表达方式" 
    
#     def on_word_click(word_info):
#         print(f"Word clicked: {word_info}")
    
#     compound_display = CompoundTextToSpeechDisplay(text=sample_text, on_word_click=on_word_click)
#     await compound_display.initialize()
#     page.add(compound_display.build())
#     page.update()

# if __name__ == "__main__":
#     ft.app(target=main)

    
