import sqlite3
from pathlib import Path
from typing import Optional, Dict
from word_info_fetcher_groq import WordInfo
from .db_schema import DB_PATH, init_db
import logging
import traceback
from utils import safe_operation  # Update this import
import edge_tts
import asyncio
import io
import pygame

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.db_path = DB_PATH
        # Initialize database on DatabaseManager instantiation
        init_db()  # Add this line
        logger.info(f"DatabaseManager initialized with DB path: {self.db_path}")

    @safe_operation("database_save")
    def save_word_info(self, word_info: WordInfo) -> Optional[int]:
        """Save word info to database. Returns word_id if successful, None if word exists"""
        if not isinstance(word_info, WordInfo):
            raise ValueError(f"Invalid word_info type: {type(word_info)}")
            
        logger.info(f"Attempting to save word: {word_info.word}")
        conn = None
        
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Check if word already exists
            c.execute("SELECT id FROM words WHERE word = ?", (word_info.word,))
            existing = c.fetchone()
            if existing:
                logger.info(f"Word {word_info.word} already exists in database")
                return existing[0]  # Return existing word ID

            # Transaction begin
            c.execute("BEGIN TRANSACTION")
            
            # Insert word
            c.execute("""
                INSERT INTO words (word, pinyin, etymology)
                VALUES (?, ?, ?)
            """, (word_info.word, word_info.pinyin, word_info.etymology))
            
            word_id = c.lastrowid
            logger.info(f"Inserted word with ID: {word_id}")
            
            # Insert related data
            self._insert_definitions(c, word_id, word_info.definitions)
            self._insert_synonyms(c, word_id, word_info.synonyms)
            self._insert_antonyms(c, word_id, word_info.antonyms)
            
            # Commit transaction
            conn.commit()
            logger.info(f"Successfully saved word {word_info.word} to database")
            return word_id
            
        except Exception as e:
            logger.error(f"Error saving word to database: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            if conn:
                conn.rollback()
            raise
            
        finally:
            if conn:
                conn.close()

    def _insert_definitions(self, cursor, word_id: int, definitions: list):
        for definition in definitions:
            cursor.execute("""
                INSERT INTO definitions (word_id, definition)
                VALUES (?, ?)
            """, (word_id, definition))
            logger.debug(f"Added definition: {definition}")

    def _insert_synonyms(self, cursor, word_id: int, synonyms: list):
        for synonym in synonyms:
            cursor.execute("""
                INSERT INTO synonyms (word_id, synonym)
                VALUES (?, ?)
            """, (word_id, synonym))
            logger.debug(f"Added synonym: {synonym}")

    def _insert_antonyms(self, cursor, word_id: int, antonyms: list):
        for antonym in antonyms:
            cursor.execute("""
                INSERT INTO antonyms (word_id, antonym)
                VALUES (?, ?)
            """, (word_id, antonym))
            logger.debug(f"Added antonym: {antonym}")

    async def generate_and_save_audio(self, word_id: int, word: str, voice_name: str = "zh-CN-XiaoxiaoNeural") -> bool:
        """Generate TTS audio and save it to database"""
        try:
            # Configure TTS
            communicate = edge_tts.Communicate(word, voice_name)
            
            # Create in-memory buffer for audio
            audio_buffer = io.BytesIO()
            
            # Generate audio
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_buffer.write(chunk["data"])
            
            # Get the audio data
            audio_data = audio_buffer.getvalue()
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Check if audio already exists
            c.execute("""
                INSERT OR REPLACE INTO word_audio (word_id, audio_blob, voice_name)
                VALUES (?, ?, ?)
            """, (word_id, audio_data, voice_name))
            
            conn.commit()
            conn.close()
            
            logger.info(f"Audio saved for word: {word}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating audio for word {word}: {e}")
            return False

    def get_word_info(self, word: str) -> Optional[Dict]:
        """Get word info from database if it exists"""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Get word info
            c.execute("""
                SELECT id, word, pinyin, etymology 
                FROM words 
                WHERE word = ?
            """, (word,))
            
            word_row = c.fetchone()
            if not word_row:
                return None
                
            word_id, word, pinyin, etymology = word_row
            
            # Get definitions
            c.execute("SELECT definition FROM definitions WHERE word_id = ?", (word_id,))
            definitions = [row[0] for row in c.fetchall()]
            
            # Get synonyms
            c.execute("SELECT synonym FROM synonyms WHERE word_id = ?", (word_id,))
            synonyms = [row[0] for row in c.fetchall()]
            
            # Get antonyms
            c.execute("SELECT antonym FROM antonyms WHERE word_id = ?", (word_id,))
            antonyms = [row[0] for row in c.fetchall()]
            
            # Get audio
            c.execute("SELECT audio_blob FROM word_audio WHERE word_id = ?", (word_id,))
            audio_row = c.fetchone()
            audio_blob = audio_row[0] if audio_row else None
            
            return {
                'id': word_id,
                'word': word,
                'pinyin': pinyin,
                'etymology': etymology,
                'definitions': definitions,
                'synonyms': synonyms,
                'antonyms': antonyms,
                'audio_blob': audio_blob
            }
            
        except Exception as e:
            logger.error(f"Error fetching word info from database: {e}")
            return None
        finally:
            if 'conn' in locals():
                conn.close()

    def play_audio_from_blob(self, audio_blob: bytes):
        """Play audio from blob data"""
        try:
            audio_buffer = io.BytesIO(audio_blob)
            pygame.mixer.init()
            pygame.mixer.music.load(audio_buffer)
            pygame.mixer.music.play()
            return True
        except Exception as e:
            logger.error(f"Error playing audio from blob: {e}")
            return False
