import sqlite3
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# Get the absolute path to the database directory
DB_DIR = Path(__file__).parent.absolute()
DB_PATH = DB_DIR / "words.db"

def init_db():
    """Initialize the database with required tables"""
    logger.info(f"Initializing database at: {DB_PATH}")
    
    try:
        # Ensure database directory exists
        DB_DIR.mkdir(parents=True, exist_ok=True)
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Create tables
        c.executescript("""
            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                pinyin TEXT NOT NULL,
                etymology TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(word)
            );

            CREATE TABLE IF NOT EXISTS word_audio (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word_id INTEGER NOT NULL,
                audio_blob BLOB NOT NULL,
                voice_name TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (word_id) REFERENCES words(id),
                UNIQUE(word_id, voice_name)
            );

            CREATE TABLE IF NOT EXISTS definitions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word_id INTEGER,
                definition TEXT NOT NULL,
                FOREIGN KEY (word_id) REFERENCES words(id)
            );

            CREATE TABLE IF NOT EXISTS synonyms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word_id INTEGER,
                synonym TEXT NOT NULL,
                FOREIGN KEY (word_id) REFERENCES words(id)
            );

            CREATE TABLE IF NOT EXISTS antonyms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word_id INTEGER,
                antonym TEXT NOT NULL,
                FOREIGN KEY (word_id) REFERENCES words(id)
            );
        """)
        
        conn.commit()
        logger.info("Database initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise
    finally:
        if 'conn' in locals():
            conn.close()

# Initialize database when module is imported
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    init_db()
