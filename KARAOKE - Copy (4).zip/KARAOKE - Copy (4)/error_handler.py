import flet as ft
from typing import Optional, Callable, Any
import logging
import traceback

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ErrorHandler:
    @staticmethod
    def show_error_dialog(page: ft.Page, title: str, message: str):
        """Display an error dialog to the user"""
        try:
            def close_dlg(_):
                dlg.open = False
                page.update()

            dlg = ft.AlertDialog(
                modal=True,
                title=ft.Text(title, color=ft.colors.RED_400, weight=ft.FontWeight.BOLD),
                content=ft.Text(message),
                actions=[
                    ft.TextButton("OK", on_click=close_dlg)
                ],
            )
            
            page.dialog = dlg
            dlg.open = True
            page.update()
            
            # Log the error
            logger.error(f"{title}: {message}")
            
        except Exception as e:
            # Fallback error logging if dialog fails
            logger.critical(f"Error showing error dialog: {str(e)}")
            logger.critical(traceback.format_exc())

    @staticmethod
    def show_error_banner(page: ft.Page, message: str, duration: int = 4000):
        """Display a temporary error banner"""
        try:
            banner = ft.Banner(
                bgcolor=ft.colors.RED_100,
                leading=ft.Icon(ft.icons.ERROR_OUTLINE, color=ft.colors.RED, size=40),
                content=ft.Text(message, color=ft.colors.RED_900),
                actions=[
                    ft.TextButton("Dismiss", on_click=lambda _: setattr(page, 'banner', None))
                ],
            )
            page.banner = banner
            page.update()
            
            # Optional: Auto-hide banner after duration
            if duration:
                page.after(duration, lambda _: setattr(page, 'banner', None))
                
        except Exception as e:
            logger.error(f"Error showing error banner: {str(e)}")

    @staticmethod
    def handle_operation(operation_name: str, 
                        callback: Callable, 
                        error_dialog: bool = True,
                        fallback_value: Any = None) -> Any:
        """Handle operations that might fail"""
        try:
            return callback()
        except Exception as e:
            error_msg = f"Error in {operation_name}: {str(e)}"
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            
            if error_dialog:
                # Get current page if available
                try:
                    page = ft.get_current_page()
                    if page:
                        ErrorHandler.show_error_dialog(page, f"Error in {operation_name}", str(e))
                except:
                    logger.error("Could not show error dialog - no active page")
            
            return fallback_value

    @staticmethod
    def log_error(error: Exception, context: str = ""):
        """Log an error with context"""
        logger.error(f"Error in {context}: {str(error)}")
        logger.error(traceback.format_exc())
