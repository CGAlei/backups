import flet as ft
from typing import Dict, Any
from constants import DimensionDisplay
from canvas_builder import CanvasBuilder
from error_handler import ErrorHandler
from utils.debug_system import debug_system





class AudioManager:
    def __init__(self):
        self.current_player = None

    def set_current_player(self, player):
        if self.current_player and self.current_player != player:
            self.current_player.stop_playback()
        self.current_player = player

    def stop_all(self):
        if self.current_player:
            self.current_player.stop_playback()
            self.current_player = None

audio_manager = AudioManager()


def main(page: ft.Page) -> None:
    debug_system.log_flow("Starting main application")
    try:
        page.window.always_on_top = True
        page.padding = 20
        page.title = "UI Test"
        page.bgcolor = ft.colors.GREY_900

        debug_system.log_flow("Creating canvas")
        builder = CanvasBuilder()
        
        # Add panels one by one with error checking
        debug_system.log_flow("Adding right panel")
        builder.add_panel('right')
        
        debug_system.log_flow("Adding left panel")
        builder.add_panel('left')
        
        debug_system.log_flow("Adding middle panel")
        builder.add_panel('middle', right_panel=builder.panels.get('right'))
        
        debug_system.log_flow("Setting layout")
        builder.set_layout()
        
        debug_system.log_flow("Building canvas")
        canvas = builder.build()

        debug_system.log_flow("Adding canvas to page")
        page.add(canvas)
        
        debug_system.log_flow("Creating dimension display")
        DimensionDisplay.create(page)
        
        debug_system.log_flow("Main application started successfully")
        
    except Exception as e:
        debug_system.log_error(e, "Main UI initialization")
        # Show error in UI
        page.add(
            ft.Container(
                content=ft.Column([
                    ft.Text("Error initializing application", color=ft.colors.RED_400, size=20),
                    ft.Text(str(e), color=ft.colors.RED_400, size=14)
                ]),
                padding=20
            )
        )

if __name__ == "__main__":
    ft.app(target=main)
