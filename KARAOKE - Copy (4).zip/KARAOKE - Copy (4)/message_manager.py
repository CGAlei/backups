import flet as ft
from typing import Callable, Any
from cttsdisplay import CompoundTextToSpeechDisplay
from state_management import app_state

class MessageManager:
    def __init__(self):
        self.message_area = None
        self.on_word_click_handler = None

    def initialize(self, message_area: ft.ListView, on_word_click: Callable):
        self.message_area = message_area
        self.on_word_click_handler = on_word_click

    def create_message_display(self, message: str) -> CompoundTextToSpeechDisplay:
        try:
            return CompoundTextToSpeechDisplay(
                text=message, 
                on_word_click=self.on_word_click_handler
            )
        except Exception as e:
            self._handle_tts_error(str(e))
            return None

    def display_message(self, message: str):
        try:
            tts_display = self.create_message_display(message)
            if not tts_display:
                return

            tts_content = tts_display.build()
            message_container = self._create_message_container(tts_display, tts_content)
            
            app_state.add_message({
                'content': message,
                'container': message_container,
                'tts_display': tts_display
            })
            
            self.message_area.controls.append(message_container)
            self.message_area.update()

        except Exception as e:
            self._handle_display_error(str(e))

    def _create_message_container(self, tts_display, tts_content) -> ft.Container:
        def on_play_message(_):
            try:
                app_state.set_current_player(tts_display)
                tts_display.start_playback()
            except Exception as e:
                self._handle_playback_error(str(e))

        def on_stop_message(_):
            try:
                tts_display.stop_playback()
            except Exception as e:
                self._handle_playback_error(str(e))

        return ft.Container(
            content=ft.Column([
                tts_content,
                ft.Row([
                    ft.IconButton(
                        icon=ft.icons.PLAY_ARROW,
                        icon_color=ft.colors.WHITE,
                        on_click=on_play_message
                    ),
                    ft.IconButton(
                        icon=ft.icons.STOP,
                        icon_color=ft.colors.WHITE,
                        on_click=on_stop_message
                    )
                ])
            ]),
            padding=10,
            border_radius=5,
            bgcolor=ft.colors.BLUE_900
        )

    def _handle_tts_error(self, error_message: str):
        self._show_error("Text-to-Speech Error", error_message)

    def _handle_display_error(self, error_message: str):
        self._show_error("Display Error", error_message)

    def _handle_playback_error(self, error_message: str):
        self._show_error("Playback Error", error_message)

    def _show_error(self, error_type: str, error_message: str):
        if self.message_area:
            error_container = ft.Container(
                content=ft.Column([
                    ft.Text(f"{error_type}:", size=16, color=ft.colors.RED_400, weight=ft.FontWeight.BOLD),
                    ft.Text(error_message, size=14, color=ft.colors.RED_200)
                ]),
                padding=10,
                border_radius=5,
                bgcolor=ft.colors.with_opacity(0.1, ft.colors.RED)
            )
            self.message_area.controls.append(error_container)
            self.message_area.update()
