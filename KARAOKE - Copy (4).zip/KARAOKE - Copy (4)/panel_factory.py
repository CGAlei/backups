import flet as ft
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod

class BasePanel(ft.Container, ABC):
    def __init__(self, config: Dict[str, Any]):
        super().__init__()
        self.expand = True
        self.width = config.get('width', 300)
        self.visible = config.get('visible', True)
        self.col = config.get('col', {"xs": 12, "sm": 6, "md": 6, "lg": 3})
        self.bgcolor = config.get('bgcolor', ft.colors.GREY_900)
        self.content = self.create_content()

    @abstractmethod
    def create_content(self):
        pass

class PanelFactory:
    @staticmethod
    def create_panel(panel_type: str, config: Optional[Dict[str, Any]] = None, **kwargs) -> BasePanel:
        from panels import LeftPanel, RightPanel, MiddlePanel  # Import here to avoid circular imports
        
        if config is None:
            config = {}
            
        panel_types = {
            'left': LeftPanel,
            'right': RightPanel,
            'middle': MiddlePanel
        }
        
        panel_class = panel_types.get(panel_type.lower())
        if not panel_class:
            raise ValueError(f"Invalid panel type: {panel_type}")
            
        return panel_class(config=config, **kwargs)

