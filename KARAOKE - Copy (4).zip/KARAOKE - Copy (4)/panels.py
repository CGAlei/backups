import flet as ft
from typing import Dict, Any
from panel_factory import BasePanel
from cttsdisplay import CompoundTextToSpeechDisplay
from constants import CardData
from compos import DoubleContainer
from main import audio_manager
from state_management import app_state
from word_info_display import WordInfoDisplay
from utils.debug_system import debug_system
from utils import safe_ui_operation  # Update this import
import threading
import logging
from word_info_fetcher_groq import WordInfoFetcher
import re

def sanitize_response(response):
    # Allow word characters, spaces, specific punctuation, and Chinese characters
    return re.sub(r'[^\w\s,.!?，。！？\u4e00-\u9fff]', '', response)

class LeftPanel(BasePanel):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)

    def create_content(self):
        card_data = CardData(range_start=301, range_size=40)
        cards_list = card_data.get_cards()
        cards = []
        for card in cards_list:
            cards.append(DoubleContainer(card["image_url"], card["description"], card["title"]))
            cards.append(ft.Divider(0, color=ft.colors.GREY_800))
        return ft.ListView(spacing=10, controls=cards, auto_scroll=True, expand=True)

class RightPanel(BasePanel):
    def __init__(self, config: Dict[str, Any]):
        self.content_column = ft.Column([
            ft.Container(
                content=ft.Text(
                    "Click on a word to see details",
                    size=16,
                    color=ft.colors.GREY_400,
                ),
                padding=20,
            )
        ])
        self.current_word = None
        super().__init__(config)
        app_state.add_observer(self)
        debug_system.log_flow("RightPanel initialized")

    def create_content(self):  # Add this required method
        return self.content_column  # Return the content column we created in __init__

    def on_word_info_update(self, state):
        debug_system.log_flow(f"Word info update received: {state.current_word_info}")
        if state.current_word_info != self.current_word:
            self.current_word = state.current_word_info
            self.update_word_info(state.current_word_info)

    @safe_ui_operation("update_word_info")
    def update_word_info(self, word_info):
        debug_system.log_flow(f"Updating word info display for: {word_info}")
        try:
            self.content_column.controls.clear()
            
            if isinstance(word_info, str):
                debug_system.log_flow(f"Handling error case: {word_info}")
                self.content_column.controls.append(
                    ft.Container(
                        content=ft.Text(
                            word_info,
                            color=ft.colors.RED_400,
                            size=16,
                        ),
                        padding=20,
                    )
                )
            else:
                debug_system.log_flow("Building word info display")
                word_info_ui = WordInfoDisplay.build_word_info_display(word_info)
                self.content_column.controls.append(word_info_ui)
            
            self.content_column.update()
            
        except Exception as e:
            debug_system.log_error(e, "Error updating word info display")
            self.content_column.controls.clear()
            self.content_column.controls.append(
                ft.Container(
                    content=ft.Text(
                        f"Error displaying word info: {str(e)}",
                        color=ft.colors.RED_400,
                        size=16,
                    ),
                    padding=20,
                )
            )
            self.content_column.update()

class MiddlePanel(BasePanel):
    def __init__(self, config: Dict[str, Any], right_panel: RightPanel):
        self.right_panel = right_panel
        super().__init__(config)
        app_state.add_observer(self)

    def on_audio_player_update(self, state):
        # Update UI based on audio player state
        pass

    def create_content(self):
        self.message_area = ft.ListView(spacing=10, auto_scroll=True, expand=True)
        text_input = ft.TextField(
            hint_text="Type your message here...",
            border_color=ft.colors.WHITE10,
            color=ft.colors.WHITE,
            expand=True,
            multiline=True,
            min_lines=1,
            max_lines=5,
            on_submit=lambda _: self.send_message(text_input),
        )
        send_button = ft.IconButton(
            icon=ft.icons.SEND,
            icon_color=ft.colors.WHITE,
            on_click=lambda _: self.send_message(text_input),
        )
        return ft.Column([
            self.message_area,
            ft.Row([text_input, send_button])
        ])

    def send_message(self, text_input):
        if text_input.value:
            message = text_input.value
            text_input.value = ""
            self.display_message(message)
            self.update()

            # Fetch AI response in a separate thread
            threading.Thread(target=self.fetch_and_display_ai_response, args=(message,)).start()

    def fetch_and_display_ai_response(self, message):
        try:
            fetcher = WordInfoFetcher()
            ai_response = fetcher.fetch_ai_response(message)
            sanitized_response = sanitize_response(ai_response)
            self.display_message(sanitized_response)
            self.update()
        except Exception as e:
            logging.error(f"Error in fetch_and_display_ai_response: {str(e)}")

    def display_message(self, message):
        tts_display = CompoundTextToSpeechDisplay(text=message, on_word_click=self.on_word_click)
        tts_content = tts_display.build()

        def on_play_message(_):
            app_state.set_current_player(tts_display)
            tts_display.start_playback()

        def on_stop_message(_):
            tts_display.stop_playback()

        message_container = ft.Container(
            content=ft.Column([
                tts_content,
                ft.Row([
                    ft.IconButton(
                        icon=ft.icons.PLAY_ARROW,
                        icon_color=ft.colors.WHITE,
                        on_click=on_play_message
                    ),
                    ft.IconButton(
                        icon=ft.icons.STOP,
                        icon_color=ft.colors.WHITE,
                        on_click=on_stop_message
                    )
                ])
            ]),
            padding=10,
            border_radius=5,
            bgcolor=ft.colors.BLUE_900
        )
        
        app_state.add_message({
            'content': message,
            'container': message_container
        })
        
        self.message_area.controls.append(message_container)
        self.message_area.update()

    def on_word_click(self, word_info):
        app_state.update_word_info(word_info)
