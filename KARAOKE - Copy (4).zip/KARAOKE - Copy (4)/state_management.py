from typing import Optional, Dict, Any, List
import flet as ft
from word_info_fetcher_groq import WordInfo
from utils.debug_system import debug_system

class AppState:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(AppState, cls).__new__(cls)
            cls._instance._initialize()
            debug_system.log_flow("AppState singleton created")
        return cls._instance

    def _initialize(self):
        self.observers: List = []
        self.current_word_info = None
        self.current_audio_player = None
        self.panel_states = {
            'left': True,
            'right': True
        }
        self.messages = []
        self.selected_message = None
        debug_system.log_flow("AppState initialized")

    def update_word_info(self, word_info: Any):
        from word_info_fetcher_groq import WordInfo  # Import here to avoid circular imports
        debug_system.log_flow(f"Updating word info: {word_info}")
        
        if isinstance(word_info, (WordInfo, str)):
            self.current_word_info = word_info
            self.notify_observers('word_info')
        else:
            debug_system.log_error(ValueError(f"Invalid word_info type: {type(word_info)}"), "update_word_info")

    def set_current_player(self, player):
        debug_system.log_flow("Setting current player")
        try:
            if self.current_audio_player and self.current_audio_player != player:
                self.current_audio_player.stop_playback()
            self.current_audio_player = player
            self.notify_observers('audio_player')
        except Exception as e:
            debug_system.log_error(e, "set_current_player")

    def stop_all_audio(self):
        debug_system.log_flow("Stopping all audio")
        try:
            if self.current_audio_player:
                self.current_audio_player.stop_playback()
                self.current_audio_player = None
            self.notify_observers('audio_player')
        except Exception as e:
            debug_system.log_error(e, "stop_all_audio")

    def toggle_panel(self, panel_name: str):
        debug_system.log_flow(f"Toggling panel: {panel_name}")
        if panel_name in self.panel_states:
            self.panel_states[panel_name] = not self.panel_states[panel_name]
            self.notify_observers('panel_state')

    def add_message(self, message: Dict):
        debug_system.log_flow("Adding message")
        try:
            self.messages.append(message)
            self.notify_observers('messages')
        except Exception as e:
            debug_system.log_error(e, "add_message")

    def add_observer(self, observer):
        if observer not in self.observers:
            self.observers.append(observer)
            debug_system.log_flow(f"Added observer: {observer.__class__.__name__}")

    def remove_observer(self, observer):
        if observer in self.observers:
            self.observers.remove(observer)
            debug_system.log_flow(f"Removed observer: {observer.__class__.__name__}")

    def notify_observers(self, update_type: str):
        debug_system.log_flow(f"Notifying observers of {update_type} update")
        observers = self.observers.copy()  # Create copy to avoid modification during iteration
        for observer in observers:
            try:
                if hasattr(observer, f'on_{update_type}_update'):
                    getattr(observer, f'on_{update_type}_update')(self)
            except Exception as e:
                debug_system.log_error(e, f"Error notifying observer: {observer.__class__.__name__}")

# Global state instance
app_state = AppState()
