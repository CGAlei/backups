import sqlite3
import pytest
from pathlib import Path
from database.db_schema import DB_PATH, init_db
from word_info_fetcher_groq import WordInfo
from database.db_manager import DatabaseManager

def test_database():
    try:
        # Initialize database
        print("Initializing database...")
        init_db()
        
        # Create test word
        print("Creating test word...")
        test_word = WordInfo(
            word="你好",
            pinyin="nǐ hǎo",
            etymology="Greeting word",
            definitions=["hello", "hi"],
            synonyms=["喂", "哈喽"],
            antonyms=[]
        )
        
        # Initialize database manager
        print("Initializing database manager...")
        db_manager = DatabaseManager()
        
        # Test saving word
        print("Testing word save...")
        word_id = db_manager.save_word_info(test_word)
        if word_id is None:
            raise Exception("Failed to save word")
        print(f"Word saved successfully with ID: {word_id}")
        
        # Test duplicate word
        print("Testing duplicate word save...")
        duplicate_id = db_manager.save_word_info(test_word)
        if duplicate_id is not None:
            raise Exception("Should not save duplicate word")
        print("Duplicate word test passed")
        
        print("\nAll tests passed successfully! ✅")
        return True
        
    except Exception as e:
        print(f"\nTest failed: {str(e)} ❌")
        return False

if __name__ == "__main__":
    test_database()
