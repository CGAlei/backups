import logging
import sys
import traceback
from datetime import datetime
from pathlib import Path
from functools import wraps
import inspect
import json
from typing import Any, Dict, Optional
import flet as ft
import os

# Get the absolute path to project root directory
PROJECT_ROOT = Path(__file__).parent.parent.absolute()
print(f"Project root directory: {PROJECT_ROOT}")

# Create logs directory with absolute path
LOGS_DIR = PROJECT_ROOT / "logs"
try:
    # Force create the logs directory
    os.makedirs(LOGS_DIR, exist_ok=True)
    print(f"Logs directory created/verified at: {LOGS_DIR}")
    
    # Test write permissions by creating a test file
    test_file = LOGS_DIR / "test.txt"
    test_file.write_text("Test write access")
    test_file.unlink()  # Remove test file
    
except Exception as e:
    print(f"Error with primary logs directory: {e}")
    # Fallback to user's home directory
    LOGS_DIR = Path.home() / "karaoke_logs"
    try:
        os.makedirs(LOGS_DIR, exist_ok=True)
        print(f"Using fallback logs directory: {LOGS_DIR}")
    except Exception as e2:
        print(f"Critical error: Cannot create logs directory: {e2}")
        raise

# Verify logs directory exists
if not LOGS_DIR.exists():
    raise RuntimeError(f"Failed to create logs directory at {LOGS_DIR}")

print(f"Using logs directory: {LOGS_DIR}")

# Create separate log files for different types of logs
current_date = datetime.now().strftime("%Y%m%d")
ERROR_LOG = LOGS_DIR / f"error_{current_date}.log"
DEBUG_LOG = LOGS_DIR / f"debug_{current_date}.log"
STATE_LOG = LOGS_DIR / f"state_{current_date}.log"

# Test write access to log files
for log_file in [ERROR_LOG, DEBUG_LOG, STATE_LOG]:
    try:
        log_file.touch()
        print(f"Verified write access to: {log_file}")
    except Exception as e:
        print(f"Error creating log file {log_file}: {e}")
        raise

class DebugSystem:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DebugSystem, cls).__new__(cls)
            cls._instance._initialize_logging()
        return cls._instance
    
    def _initialize_logging(self):
        # Main error logger
        self.error_logger = logging.getLogger('error')
        self.error_logger.setLevel(logging.ERROR)
        error_handler = logging.FileHandler(ERROR_LOG)
        error_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(levelname)s - %(module)s - %(message)s')
        )
        self.error_logger.addHandler(error_handler)
        
        # Debug logger for flow tracking
        self.debug_logger = logging.getLogger('debug')
        self.debug_logger.setLevel(logging.DEBUG)
        debug_handler = logging.FileHandler(DEBUG_LOG)
        debug_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(module)s - %(funcName)s - %(message)s')
        )
        self.debug_logger.addHandler(debug_handler)
        
        # State logger for object states
        self.state_logger = logging.getLogger('state')
        self.state_logger.setLevel(logging.INFO)
        state_handler = logging.FileHandler(STATE_LOG)
        state_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(message)s')
        )
        self.state_logger.addHandler(state_handler)

    def log_error(self, error: Exception, context: str = ""):
        """Log detailed error information"""
        error_info = {
            "timestamp": datetime.now().isoformat(),
            "type": type(error).__name__,
            "message": str(error),
            "context": context,
            "traceback": traceback.format_exc(),
            "stack_info": traceback.extract_stack().format()
        }
        self.error_logger.error(json.dumps(error_info, indent=2))

    def log_state(self, obj: Any, state_name: str):
        """Log object state"""
        try:
            if hasattr(obj, '__dict__'):
                state = {
                    "object_type": type(obj).__name__,
                    "state_name": state_name,
                    "attributes": {k: str(v) for k, v in obj.__dict__.items()}
                }
                self.state_logger.info(json.dumps(state, indent=2))
        except Exception as e:
            self.log_error(e, f"Failed to log state for {type(obj).__name__}")

    def log_flow(self, message: str, level: str = "DEBUG"):
        """Log application flow"""
        frame = inspect.currentframe().f_back
        func_name = frame.f_code.co_name
        module_name = inspect.getmodule(frame).__name__
        
        flow_info = {
            "module": module_name,
            "function": func_name,
            "message": message
        }
        self.debug_logger.debug(json.dumps(flow_info, indent=2))

debug_system = DebugSystem()

def track_flow(func):
    """Decorator to track function entry and exit"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        debug_system.log_flow(f"Entering {func.__name__}")
        try:
            result = func(*args, **kwargs)
            debug_system.log_flow(f"Exiting {func.__name__} successfully")
            return result
        except Exception as e:
            debug_system.log_error(e, f"Error in {func.__name__}")
            debug_system.log_flow(f"Exiting {func.__name__} with error: {str(e)}")
            raise
    return wrapper

def safe_ui_operation(operation_name: str):
    """Decorator for UI operations with error handling"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                debug_system.log_flow(f"Starting UI operation: {operation_name}")
                result = func(*args, **kwargs)
                debug_system.log_flow(f"Completed UI operation: {operation_name}")
                return result
            except Exception as e:
                debug_system.log_error(e, f"UI operation failed: {operation_name}")
                
                # Show error in UI
                try:
                    if ft.Page.instance:
                        ft.Page.instance.show_snack_bar(
                            ft.SnackBar(
                                content=ft.Text(
                                    f"Operation failed: {str(e)}",
                                    color=ft.colors.WHITE
                                ),
                                bgcolor=ft.colors.RED_700,
                            )
                        )
                except Exception as ui_error:
                    debug_system.log_error(ui_error, "Failed to show error in UI")
                
                # Return a safe fallback UI component
                return ft.Container(
                    content=ft.Text(
                        "An error occurred",
                        color=ft.colors.RED_400
                    ),
                    padding=10
                )
        return wrapper
    return decorator
