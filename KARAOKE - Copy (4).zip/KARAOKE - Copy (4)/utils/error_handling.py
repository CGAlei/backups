import logging
import traceback
import flet as ft
from typing import Callable, Any
from functools import wraps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def safe_ui_operation(operation_name: str):
    """
    Decorator for safely executing UI operations that might fail
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in {operation_name}: {str(e)}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                
                # Show error in UI if page instance exists
                try:
                    if ft.Page.instance:
                        ft.Page.instance.show_snack_bar(
                            ft.SnackBar(
                                content=ft.Text(
                                    f"Operation failed: {str(e)}",
                                    color=ft.colors.WHITE
                                ),
                                bgcolor=ft.colors.RED_700,
                            )
                        )
                except Exception as ui_error:
                    logger.error(f"Failed to show error in UI: {str(ui_error)}")
                
                return None
        return wrapper
    return decorator

def safe_operation(operation_name: str):
    """
    Decorator for safely executing operations that might fail
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in {operation_name}: {str(e)}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                return None
        return wrapper
    return decorator
