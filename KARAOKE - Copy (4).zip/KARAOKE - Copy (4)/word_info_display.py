import flet as ft
from typing import Dict, Any
from word_info_fetcher_groq import WordInfo
import sqlite3
from database.db_schema import DB_PATH  # Add this import
from database.db_manager import DatabaseManager  # Add this import
from utils.error_handling import safe_operation, logger  # Add this import
from utils.debug_system import debug_system, track_flow, safe_ui_operation
import edge_tts
import asyncio
import pygame
import io

class WordInfoDisplay:
    @staticmethod
    def create_info_container(title: str, content: str) -> ft.Container:
        return ft.Container(
            content=ft.Column([
                ft.Text(title, size=14, color=ft.colors.GREY_400),
                ft.Text(content, size=16, color=ft.colors.WHITE),
            ]),
            padding=10,
            margin=ft.margin.only(bottom=5),
            bgcolor=ft.colors.with_opacity(0.1, ft.colors.WHITE),
            border_radius=8,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=4,
                color=ft.colors.with_opacity(0.2, ft.colors.BLACK),
            ),
            animate=ft.animation.Animation(300, ft.AnimationCurve.EASE_OUT),
        )

    @staticmethod
    def create_list_container(title: str, items: list) -> ft.Container:
        items_row = ft.Row(
            controls=[
                ft.Container(
                    content=ft.Text(item, size=14),
                    padding=5,
                    bgcolor=ft.colors.with_opacity(0.2, ft.colors.BLUE_GREY_700),
                    border_radius=15,
                ) for item in items if items
            ],
            wrap=True,
            spacing=5,
        )

        return ft.Container(
            content=ft.Column([
                ft.Text(title, size=14, color=ft.colors.GREY_400),
                items_row,
            ]),
            padding=10,
            margin=ft.margin.only(bottom=5),
            bgcolor=ft.colors.with_opacity(0.1, ft.colors.WHITE),
            border_radius=8,
        )

    @staticmethod
    def handle_hover(e):
        if e.data == "true":
            e.control.scale = 1.02
        else:
            e.control.scale = 1.0
        e.control.update()

    @staticmethod
    @safe_ui_operation("build_word_info_display")
    @track_flow
    def build_word_info_display(word_info: WordInfo) -> ft.Column:
        debug_system.log_flow(f"Building display for word: {word_info.word if word_info else 'None'}")
        debug_system.log_state(word_info, "word_info_input")
        
        if not isinstance(word_info, WordInfo):
            logger.error(f"Invalid word_info type: {type(word_info)}")
            return ft.Column([
                ft.Text("Error: Invalid word information", 
                       color=ft.colors.RED_400, 
                       size=16)
            ])
        
        # Main word and pinyin container
        def play_audio_sync(e, word_info: WordInfo):
            """Play audio with DB check first"""
            try:
                db_manager = DatabaseManager()
                
                # Try to get word info from DB
                db_word = db_manager.get_word_info(word_info.word)
                
                if db_word and db_word['audio_blob']:
                    # Play existing audio from DB
                    if db_manager.play_audio_from_blob(db_word['audio_blob']):
                        e.page.show_snack_bar(
                            ft.SnackBar(
                                content=ft.Text("Playing audio from database..."),
                                bgcolor=ft.colors.BLUE_700
                            )
                        )
                        return
                
                # If no audio in DB, generate new
                communicate = edge_tts.Communicate(word_info.word, "zh-CN-XiaoxiaoNeural")
                
                # Create in-memory buffer
                audio_buffer = io.BytesIO()
                
                # Generate audio synchronously
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                async def generate():
                    async for chunk in communicate.stream():
                        if chunk["type"] == "audio":
                            audio_buffer.write(chunk["data"])
                
                loop.run_until_complete(generate())
                loop.close()
                
                # Save to DB if word exists
                if db_word:
                    audio_data = audio_buffer.getvalue()
                    # Save audio directly instead of using create_task
                    conn = sqlite3.connect(DB_PATH)
                    c = conn.cursor()
                    try:
                        c.execute("""
                            INSERT OR REPLACE INTO word_audio (word_id, audio_blob, voice_name)
                            VALUES (?, ?, ?)
                        """, (db_word['id'], audio_data, "zh-CN-XiaoxiaoNeural"))
                        conn.commit()
                        debug_system.log_flow(f"Audio saved for word: {word_info.word}")
                    except Exception as e:
                        debug_system.log_error(e, "Error saving audio to database")
                    finally:
                        conn.close()
                
                # Play audio
                audio_buffer.seek(0)
                pygame.mixer.init()
                pygame.mixer.music.load(audio_buffer)
                pygame.mixer.music.play()
                
                e.page.show_snack_bar(
                    ft.SnackBar(
                        content=ft.Text("Playing generated audio..."),
                        bgcolor=ft.colors.BLUE_700
                    )
                )
                
            except Exception as err:
                debug_system.log_error(err, "Error playing audio")
                e.page.show_snack_bar(
                    ft.SnackBar(
                        content=ft.Text("Error playing audio"),
                        bgcolor=ft.colors.RED_700
                    )
                )

        # Fix the button click handler
        header = ft.Container(
            content=ft.Row([
                ft.Column([
                    ft.Text(
                        word_info.word,
                        size=40,
                        weight=ft.FontWeight.BOLD,
                        color=ft.colors.BLUE_200,
                    ),
                    ft.Text(
                        word_info.pinyin,
                        size=24,
                        italic=True,
                        color=ft.colors.ORANGE_200,
                    ),
                ]),
                ft.Row([
                    ft.IconButton(
                        icon=ft.icons.SAVE,
                        icon_color=ft.colors.WHITE,
                        tooltip="Save word",
                        on_click=lambda e: WordInfoDisplay.save_word_info(word_info, e.page)
                    ),
                    ft.IconButton(
                        icon=ft.icons.VOLUME_UP,
                        icon_color=ft.colors.WHITE,
                        tooltip="Play pronunciation",
                        on_click=lambda e: play_audio_sync(e, word_info)  # Pass both event and word_info
                    ),
                ])
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=20,
            margin=ft.margin.only(bottom=10),
            bgcolor=ft.colors.with_opacity(0.1, ft.colors.WHITE),
            border_radius=10,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=10,
                color=ft.colors.with_opacity(0.3, ft.colors.BLACK),
            ),
            animate=ft.animation.Animation(300, ft.AnimationCurve.EASE_OUT),
            on_hover=WordInfoDisplay.handle_hover,
        )

        # Create other info containers
        etymology = WordInfoDisplay.create_info_container("Etymology", word_info.etymology)
        
        definitions = ft.Container(
            content=ft.Column([
                ft.Text("Definitions", size=14, color=ft.colors.GREY_400),
                *[ft.Text(f"• {d}", size=16, color=ft.colors.WHITE) 
                  for d in word_info.definitions]
            ]),
            padding=10,
            margin=ft.margin.only(bottom=5),
            bgcolor=ft.colors.with_opacity(0.1, ft.colors.WHITE),
            border_radius=8,
        )

        synonyms = WordInfoDisplay.create_list_container("Synonyms", word_info.synonyms)
        antonyms = WordInfoDisplay.create_list_container("Antonyms", word_info.antonyms)

        return ft.Column(
            controls=[
                header,
                ft.Divider(color=ft.colors.GREY_800),
                etymology,
                definitions,
                synonyms,
                antonyms,
            ],
            scroll=ft.ScrollMode.AUTO,
            spacing=10,
        )

    @staticmethod
    async def play_audio(word: str, page: ft.Page):
        """Play TTS audio for a word"""
        try:
            page.show_snack_bar(
                ft.SnackBar(
                    content=ft.Text("Generating audio..."),
                    bgcolor=ft.colors.BLUE_700
                )
            )
            
            # Configure TTS
            communicate = edge_tts.Communicate(word, "zh-CN-XiaoxiaoNeural")
            
            # Create in-memory buffer
            audio_buffer = io.BytesIO()
            
            # Generate audio
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_buffer.write(chunk["data"])
            
            # Play audio
            audio_buffer.seek(0)
            pygame.mixer.init()
            pygame.mixer.music.load(audio_buffer)
            pygame.mixer.music.play()
            
        except Exception as e:
            debug_system.log_error(e, "Error playing audio")
            page.show_snack_bar(
                ft.SnackBar(
                    content=ft.Text("Error playing audio"),
                    bgcolor=ft.colors.RED_700
                )
            )

    @staticmethod
    @safe_ui_operation("save_word_info")
    @track_flow
    def save_word_info(word_info: WordInfo, page: ft.Page):  # Add page parameter
        debug_system.log_flow(f"Attempting to save word: {word_info.word}")
        debug_system.log_state(word_info, "word_info_to_save")
        
        if not isinstance(word_info, WordInfo):
            logger.error(f"Invalid word_info type: {type(word_info)}")
            raise ValueError("Invalid word info format")
            
        db_manager = DatabaseManager()
        word_id = db_manager.save_word_info(word_info)
        
        if word_id:
            logger.info(f"Successfully saved word: {word_info.word}")
            page.show_snack_bar(  # Use the passed page reference
                ft.SnackBar(
                    content=ft.Text(f"Word '{word_info.word}' saved successfully!"),
                    bgcolor=ft.colors.GREEN_700
                )
            )
        else:
            logger.info(f"Word already exists: {word_info.word}")
            page.show_snack_bar(  # Use the passed page reference
                ft.SnackBar(
                    content=ft.Text(f"Word '{word_info.word}' already exists in database"),
                    bgcolor=ft.colors.YELLOW_700
                )
            )
