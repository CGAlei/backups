from pydantic import BaseModel
from typing import List
import os
from dotenv import load_dotenv
import logging
from groq import Groq
import json
from cache_manager import CacheManager
from error_handler import ErrorHandler
import asyncio
import threading
import time
import functools

def retry_on_exception(retries=3, delay=1):
    def decorator_retry(func):
        @functools.wraps(func)
        def wrapper_retry(*args, **kwargs):
            last_exception = None
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    logger.warning(f"Attempt {attempt + 1} failed: {str(e)}. Retrying in {delay} seconds...")
                    time.sleep(delay)
            logger.error(f"All {retries} attempts failed.")
            raise last_exception
        return wrapper_retry
    return decorator_retry


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize Groq client
client = Groq(api_key=os.getenv('GROQ_API_KEY'))

# Pydantic model
class WordInfo(BaseModel):
    word: str
    pinyin: str
    etymology: str
    definitions: List[str]
    synonyms: List[str]
    antonyms: List[str]

# Eord Info Fetcher
class WordInfoFetcher:
    # Init
    def __init__(self):
        self.model = "llama-3.2-90b-text-preview"

    # fetch word info
    def fetch_word_info(self, word: str) -> WordInfo:
        try:
            # Use static method directly
            logger.info(f"Checking cache for word: {word}")
            cached_info = CacheManager.get_word_info(word)
            
            if cached_info:
                logger.info(f"Cache hit for word: {word}")
                if isinstance(cached_info, dict):
                    return WordInfo(**cached_info)
                return cached_info

            logger.info(f"Cache miss for word: {word}, fetching from API...")
            word_info = self._fetch_from_api(word)
            
            # Cache the result using static method
            CacheManager.cache_word_info(word, word_info.dict())
            return word_info

        except Exception as e:
            logger.error(f"Error fetching word info for '{word}': {str(e)}")
            return self._create_error_word_info(word)

    def _fetch_from_api(self, word: str) -> WordInfo:
        completion = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant that provides information about Chinese words. Respond with a JSON object that strictly follows the structure provided by the user."},
                {"role": "user", "content": f"""Provide detailed information about the Chinese word '{word}' in the following JSON structure:
                    {{
                        "word": "{word}",
                        "pinyin": "Pinyin pronunciation",
                        "etymology": "Brief etymology",
                        "definitions": ["Definition 1", "Definition 2", ...],
                        "synonyms": ["Synonym 1", "Synonym 2", ...],
                        "antonyms": ["Antonym 1", "Antonym 2", ...]
                    }}
                    Ensure all fields are filled with accurate information."""},
            ],
            response_format={"type": "json_object"},  # Ensure Groq outputs a valid JSON object
            max_tokens=1024  # Adjust as necessary
        )

        # Parse the JSON response
        response_content = json.loads(completion.choices[0].message.content)

        # Ensure all required fields are present
        for field in WordInfo.__annotations__.keys():
            if field not in response_content:
                raise ValueError(f"Missing field: {field}")

        # Create WordInfo object
        word_data = WordInfo(**response_content)
        
        # Remove this line as we already cache in fetch_word_info
        # CacheManager.cache_word_info(word, word_data)
        return word_data

    def _create_error_word_info(self, word: str) -> WordInfo:
        return WordInfo(
            word=word,
            pinyin="N/A",
            etymology="Error fetching data",
            definitions=["Unable to fetch definitions"],
            synonyms=[],
            antonyms=[]
        )

    @retry_on_exception(retries=3, delay=2)
    def fetch_ai_response(self, message: str) -> str:
        try:
            logger.info(f"Fetching AI response for message: {message}")
            completion = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": message},
                ],
                response_format={"type": "text"},  # Assuming text response
                max_tokens=1024
            )

            response_content = completion.choices[0].message.content
            logger.info(f"Received AI response: {response_content}")
            return response_content

        except Exception as e:
            logger.error(f"Error fetching AI response: {str(e)}")
            raise

# Usage example:
# fetcher = WordInfoFetcher()
# word_info = fetcher.fetch_word_info("你好")
# print(word_info.json())
